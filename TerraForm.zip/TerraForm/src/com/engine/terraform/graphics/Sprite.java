package com.engine.terraform.graphics;

public class Sprite {

	//Use E900FF For any transparency
	//For some reason the value turns out to -1507073
	
	
	public final int SIZE;
	private int x, y;
	public int[] pixels;
	private SpriteSheet sheet;
	private int transparency = -1507073;
	
	//Sprites go here!
	//TILES BELOW!
	public static Sprite voidSprite = new Sprite(16, 0x000000);
    public static Sprite sandSpriteSolid = new Sprite(16,0,0,SpriteSheet.TileSheet);	
    
    //Dirt Sprite
	public static Sprite dirtSpriteSolid = new Sprite(16,1,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteRightMid = new Sprite(16,2,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteTopLeft = new Sprite(16,3,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteTopMid = new Sprite(16,4,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteTopRight = new Sprite(16,5,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteBottomLeft = new Sprite(16,6,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteBottomMid = new Sprite(16,7,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteBottomRight = new Sprite(16,8,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteLeftMid = new Sprite(16,9,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteMid = new Sprite(16,10,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteNoLeftRight = new Sprite(16,11,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteNoLeftBottom = new Sprite(16,12,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteOnlyBottom= new Sprite(16,13,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteOnlyLeft = new Sprite(16,11,1,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteOnlyTop = new Sprite(16,12,1,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteOnlyRight = new Sprite(16,13,1,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteNoRightBottom = new Sprite(16,14,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteNoLeftTop = new Sprite(16,15,0,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteNoTopBottom = new Sprite(16,14,1,SpriteSheet.TileSheet);
	public static Sprite dirtSpriteNoRightTop = new Sprite(16,15,1,SpriteSheet.TileSheet);
	
	//Water Sprites
	public static Sprite waterSpriteSolid = new Sprite(16,0,1,SpriteSheet.TileSheet);
	
	//Water+Sand
	public static Sprite waterSpriteSandLeft = new Sprite(16,1,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandTop = new Sprite(16,2,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandRight = new Sprite(16,3,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandBottom = new Sprite(16,4,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandRightTop = new Sprite(16,5,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandLeftTop = new Sprite(16,6,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandLeftBottom = new Sprite(16,7,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandRightBottom = new Sprite(16,8,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandLeftRight = new Sprite(16,8,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteSandTopBottom = new Sprite(16,9,2,SpriteSheet.TileSheet);
	
	//Water+Dirt
	public static Sprite waterSpriteDirtTop = new Sprite(16,10,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtBottom = new Sprite(16,11,1,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtLeft = new Sprite(16,0,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtRight = new Sprite(16,1,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtRightTop = new Sprite(16,2,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtLeftTop = new Sprite(16,3,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtRightBottom = new Sprite(16,4,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtLeftBottom = new Sprite(16,5,2,SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtLeftRight = new Sprite(16,6,2, SpriteSheet.TileSheet);
	public static Sprite waterSpriteDirtTopBottom = new Sprite(16,7,2,SpriteSheet.TileSheet);
	
	
	//Building Sprites go Below! :)
	//HQ
	public static Sprite HQSprite = new Sprite(32,0,0,SpriteSheet.Buildings);
	
	//Barracks
	public static Sprite BarracksLeft = new Sprite(16,2,0,SpriteSheet.Buildings);
	public static Sprite BarracksRight = new Sprite(16,3,0,SpriteSheet.Buildings);
	
	//Farm
	public static Sprite FarmLeft = new Sprite(16,4,0,SpriteSheet.Buildings);
	public static Sprite FarmRight = new Sprite(16,5,0,SpriteSheet.Buildings);
	
	//Storage Silo
	public static Sprite storageSilo = new Sprite(16,0,2,SpriteSheet.Buildings);
	
	//BASES
	//Base Without Bubble
	public static Sprite baseNoBubble = new Sprite(32,0,2,SpriteSheet.Buildings);
	public static Sprite baseWithBubble = new Sprite(32,1,2,SpriteSheet.Buildings);
	
	
	//Player UI WRONG
	public static Sprite UI = new Sprite(540,0,0,SpriteSheet.PlayerUI);
	
	public Sprite(int size, int x, int y, SpriteSheet sheet){
		this.SIZE = size;
		pixels = new int[size*size];
		this.x = x*size;
		this.y = y*size;
		this.sheet = sheet;
		load();
	}
	
	public Sprite(int size, int color){
		SIZE = size;
		pixels = new int[size*size];
		setColor(color);
	}
	
	private void setColor(int color){
		for(int i = 0; i < SIZE*SIZE; i++){
			pixels[i] = color;
		}
	}
	
	public void load(){
		for(int y = 0; y < SIZE; y++){
			for(int x = 0; x < SIZE; x++){
					pixels[x+y*SIZE] = sheet.pixels[(this.x+x)+(this.y+y)*sheet.SIZE];
			}
		}
	}
	
	public int getSize(){
		return this.SIZE;
	}
	
}
