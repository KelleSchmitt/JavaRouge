package com.engine.terraform.graphics;

import java.awt.Color;
import java.util.Random;

import com.engine.terraform.entity.light.DayCycle;
import com.engine.terraform.entity.light.Light;
import com.engine.terraform.input.Keyboard;
import com.engine.terraform.input.Mouse;
import com.engine.terraform.level.tile.Tile;

public class Screen {
	public int width;
	public int height;
	public final int MAP_SIZE = 64;
	public final int Map_SIZE_MASK = MAP_SIZE-1;
	public int[] pixels;
	public int xOffset, yOffset;
	public int tiles[] = new int[MAP_SIZE*MAP_SIZE];
	private Random random = new Random();
	
	//For transparency, use -1507073 as the value. If the hex color is in there,
	//Then it won't render it onto the screen.
	
	
	public Screen(int width, int height){
		this.width = width;
		this.height = height;
		pixels = new int[width*height];
		
		for(int i = 0; i < tiles.length; i++){
			tiles[i] = random.nextInt(0xffffff);
		}
	}
	
	public void clear(){
		for(int i = 0; i < pixels.length; i++){
			pixels[i] = 0;
		}
	}
	
	public void renderTile(int xp, int yp, Tile tile){
		xp -= xOffset;
		yp -= yOffset;;
		for(int y = 0; y < tile.sprite.SIZE; y++){
			int ya = y + yp;
			for(int x = 0; x < tile.sprite.SIZE; x++){
				int xa = x + xp;
				if(xa < -tile.sprite.SIZE || xa >= width || ya < 0 || ya >= height ) break;
				if(xa < 0) xa = 0;
				if(tile.sprite.pixels[x+y*tile.sprite.SIZE] != -1507073 ){
					pixels[xa+ya*width] = tile.sprite.pixels[x+y*tile.sprite.SIZE];
				}
			}
		}
		
	}
	
	public void renderTile(Tile tile){
		int xp =(((Mouse.mouseX-32)/(3)));
		int yp = (((Mouse.mouseY-32)/(3)));
		for(int y = 0; y < tile.sprite.SIZE; y++){
			int ya = y + yp;
			for(int x = 0; x < tile.sprite.SIZE; x++){
				int xa = x + xp;
				if(xa < -tile.sprite.SIZE || xa >= width || ya < 0 || ya >= height) break;
				if(xa < 0) xa = 0;
				if(tile.sprite.pixels[x+y*tile.sprite.SIZE] != -1507073){
					pixels[xa+ya*width] = tile.sprite.pixels[x+y*tile.sprite.SIZE];
				}
			}
		}
	}
	
	public void renderBuilding(int xp, int yp, Tile tile){
		xp = (((xp-32)/(3))) - xOffset;
		yp = (((yp-32)/(3))) - yOffset;
		for(int y = 0; y < tile.sprite.SIZE; y++){
			int ya = y + yp;
			for(int x = 0; x < tile.sprite.SIZE; x++){
				int xa = x + xp;
				if(xa < -tile.sprite.SIZE || xa >= width || ya < 0 || ya >= height) break;
				if(xa < 0) xa = 0;
				if(tile.sprite.pixels[x+y*tile.sprite.SIZE] != -1507073){
					pixels[xa+ya*width] = tile.sprite.pixels[x+y*tile.sprite.SIZE];
				}
			}
		}
	}

	
	public void renderUI(int xp, int yp, Sprite sprite){
		xp -= xOffset;
		yp -= yOffset;
		for(int y = 0; y < sprite.SIZE; y++){
			int ya = y +yp;
			for(int x = 0; x < sprite.SIZE; x++){
				int xa = x + xp;
				if(xa < -sprite.SIZE || xa >= width || ya < 0 || ya > height) break;
				if(xa < 0) xa = 0;
				int col = sprite.pixels[x+y*sprite.SIZE];
				//if(col != 0xff6DBD75) pixels[xa+ya*width] = col;
			}
		}
	}
	
	public void renderLight(int xp, int yp, Light light){
		xp -= xOffset;
		yp -= yOffset;
		
		int midPoint[] = {(xp+light.lightDistance/2),(yp+light.lightDistance/2)};
		
		for(int y = 0; y < light.lightDistance; y++){
			int ya = y + yp;
			for(int x = 0; x < light.lightDistance; x++){
				int xa = x + xp;
				if(xa < -light.lightDistance || xa >= width || ya < 0 || ya >= height) break;
				if(xa < 0) xa = 0;
				
				//Get the color, and add some to it.
				Color c = new Color(pixels[xa+ya*width]);
				int red = c.getRed();
				int blue = c.getBlue();
				int green = c.getGreen();
				if(xa > midPoint[0]){
					red+=light.lightIntensity + 2*(midPoint[0]-xa);
					blue+=light.lightIntensity + 2*(midPoint[0]-xa);
					green+=light.lightIntensity + 2*(midPoint[0]-xa);
				}else{
					red+=light.lightIntensity - 2*(midPoint[0]-xa);
					blue+=light.lightIntensity - 2*(midPoint[0]-xa);
					green+=light.lightIntensity - 2*(midPoint[0]-xa);
				}
				if(ya > midPoint[1]){
					red+=2*(midPoint[1]-ya);
					blue+=2*(midPoint[1]-ya);
					green+=2*(midPoint[1]-ya);
				}else{
					red+=-2*(midPoint[1]-ya);
					blue+=-2*(midPoint[1]-ya);
					green+=-2*(midPoint[1]-ya);
				}
				if(red > 255) red = 255;
				if(blue > 255) blue = 255;
				if(green > 255) green = 255;
				if(red < c.getRed()) red = c.getRed();
				if(blue < c.getBlue()) blue = c.getBlue();
				if(green < c.getGreen()) green = c.getGreen();
				c = new Color(red,green,blue);
				pixels[xa+ya*width] = c.getRGB();
			}
		}
	}
	
	public void renderDayCycle(int xp, int yp, Light light){
		
		xp -= xOffset;
		yp -= yOffset;
		Color c;
		
		for(int y = 0; y < height; y++){
			int ya = y + yp;
			for(int x = 0; x < width; x++){
				int xa = x + xp;
				if(xa > width+10 || ya < 0 || ya > height+10) break;
				if(xa < 0) xa = 0;
				
				c = new Color(pixels[xa+ya*width]);
				
				int red = c.getRed();
				int green = c.getGreen();
				int blue = c.getBlue();
				
				
				if(DayCycle.goingDark){
					if(red<251){
						red += 5;
					}
					if(green<251){
						green += 5;
					}
					if(blue<251){
						blue += 5;
					}
					
				}else{
					
					if(red < 251){
						red += 5;
					}
					if(green < 251){
						green += 5;
					}
					if(blue < 251){
						blue += 5;
					}
					
				}
				
				c = new Color(red,green,blue);
				pixels[xa+ya*width] = c.getRGB();
			}
		}
	}
	
	public void setOffset(int xOffset, int yOffset){
		this.xOffset = xOffset;
		this.yOffset = yOffset;
	}
}
