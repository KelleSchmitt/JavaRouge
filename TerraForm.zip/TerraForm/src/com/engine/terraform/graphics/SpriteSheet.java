package com.engine.terraform.graphics;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;


public class SpriteSheet {

	private String path;
	protected final int SIZE;
	public int[] pixels;
	
	//SpriteSheets go here
	public static SpriteSheet TileSheet = new SpriteSheet("/Textures/TileSheet.png",256);
	public static SpriteSheet Buildings = new SpriteSheet("/Textures/Buildings.png",256);
	public static SpriteSheet PlayerUI = new SpriteSheet("/Textures/UI.png",540);
	
	public SpriteSheet(String path, int size){
		this.path = path;
		this.SIZE = size;
		this.pixels = new int[SIZE*SIZE];
		load();
	}
	
	private void load(){
		try{
			BufferedImage image = ImageIO.read(SpriteSheet.class.getResource(path));
			int w = image.getWidth();
			int h = image.getHeight();
			
			image.getRGB(0, 0,w,h,pixels,0,w);
			
		}catch(IOException e){e.printStackTrace();}
	}
	
}
