package com.engine.terraform.entity.mob;

import java.awt.event.KeyEvent;
import java.io.Serializable;

import com.engine.terraform.TerraForm;
import com.engine.terraform.Utilities.Point;
import com.engine.terraform.entity.buildings.Building;
import com.engine.terraform.entity.buildings.Farm;
import com.engine.terraform.entity.buildings.HeadQuarters;
import com.engine.terraform.entity.buildings.Silo;
import com.engine.terraform.entity.light.DayCycle;
import com.engine.terraform.graphics.Screen;
import com.engine.terraform.graphics.Sprite;
import com.engine.terraform.input.Keyboard;
import com.engine.terraform.input.Mouse;
import com.engine.terraform.level.BuildLevel;
import com.engine.terraform.level.Level;
import com.engine.terraform.level.tile.Tile;

public class Player implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private transient Keyboard input;
	private transient Mouse mouse;
	private transient Sprite sprite;
	private transient Tile mouseTile;
	public int x;
	public int y;
	public int id;
	public static int time;
	public String name = "";
	public static int[] worldTiles;
	public static int[] baseTiles;
	public Level currentMap;
	public Level buildZone;
	public int xView;
	public int yView;
	public int tileX;
	public int tileY;
	
	//Starting values;
	public int gold = 12500;
	public int wood = 1000;
	public int stone = 1500;
	public int iron = 100;
	public int coal = 250;
	public int copper = 10;
	public int steel = 0;
	public int morale = 50;
	public int food = 10000;
	public int water = 10000;
	public int ammo = 1000;
	public int guns = 10;
	public int armor = 10;
	public int meds = 100;
	public int kills = 0;
	public int deaths = 0;
	public int exp = 0;
	public String rank = "Private";
	
	
	
	//Incremental Values
	public int goldIncrement = 50;
	public int woodIncrement = 0;
	public int stoneIncrement = 0;
	public int ironIncrement = 0;
	public int coalIncrement = 0;
	public int copperIncrement = 0;
	public int steelIncrement = 0;
	public int moraleIncrement = 0;
	public int foodIncrement = 0;
	public int waterIncrement = 0;
	public int ammoIncrement = 0;
	public int gunsIncrement = 0;
	public int armorIncrement = 0;
	public int medsIncrement = 0;
	
	
	public Player(Keyboard input){
		this.input = input;
		this.time = 0;
		this.sprite = Sprite.UI;
		this.xView = TerraForm.width/2;
		this.yView = TerraForm.height/2;
		this.mouseTile = null;
		
		addStartingBuildings();
		addStartingLights();
	}
	
	public Player(int x, int y, Keyboard input, Mouse mouse, Level buildZone){
		this.x = x;
		this.y = y;
		this.input = input;
		this.mouse = mouse;
		this.buildZone = buildZone;
		this.time = 0;
		this.sprite = Sprite.UI;
		this.xView = TerraForm.width/2;
		this.yView = TerraForm.height/2;
		this.mouseTile = null;
		
		addStartingBuildings();
		addStartingLights();
	}
	
	public void update(){
		int xa = 0;
		int ya = 0;
		if(input.up)ya--;
		if(input.down)ya++;
		if(input.left)xa--;
		if(input.right)xa++;
		
		if(input.space){
			if(TerraForm.isBuilding){
				TerraForm.isBuilding = false;
				TerraForm.mainWorld = true;
				x = xView;
				y = yView;
				
				input.keyReleasedSetter(KeyEvent.VK_SPACE, false);
			}else{
				TerraForm.mainWorld = false;
				TerraForm.isBuilding = true;
				xView = x;
				yView = y;
				x = TerraForm.width/2 - 10; 
				y = TerraForm.height/2 - 10;
				
				input.keyReleasedSetter(KeyEvent.VK_SPACE, false);
				tileX = 0;
				tileY = 0;
			}
		}
		if(input.j) tileX--;
		if(input.k) tileY++;
		if(input.i) tileY--;
		if(input.l) tileX++;
		if(mouse.isClicked && TerraForm.isBuilding && this.mouseTile != null){
			int buildX = Mouse.mouseX- TerraForm.width -90 + x*3;
			int buildY = Mouse.mouseY- TerraForm.height -90 + y*3; 
			
			if(this.mouseTile.sprite == Tile.HQTile.sprite){ 
					if(!((BuildLevel) buildZone).checkCollisions(buildX, buildY, 128, 128)){
						if(gold >= 500){
							gold -= 500;
							addBuilding(new HeadQuarters(buildX,buildY,"Mine",100,"500 Gold"));
						}
				}else{
					System.out.println("Collision!");
				}
				
			}
			if(this.mouseTile.sprite == Tile.storageSiloTile.sprite){
				
				if(!((BuildLevel) buildZone).checkCollisions(buildX,  buildY,  128,  128)){
					
					if(gold >= 1000){
						gold -= 1000;
						addBuilding( new Silo(buildX, buildY, "Silo", 100, "10 Gold"));
					}
				}else{
					System.out.println("Collision!");
				}
				
			}
			
			
			
		}
		
		x += xa;
		y += ya;
		
		time++;
		
		if(time%1000 == 0){
			updateResources();
			//dayCycle();
		}
	}
	
	public void updateResources(){
		gold += goldIncrement;
		wood += woodIncrement;
		stone += stoneIncrement;
		iron += ironIncrement;
		coal += coalIncrement;
		copper += copperIncrement;
		steel += steelIncrement;
		morale += moraleIncrement;
		food += foodIncrement;
		water += waterIncrement;
		ammo += ammoIncrement;
		guns += gunsIncrement;
		armor += armorIncrement;
		meds += medsIncrement;
		time = 0;
	}
	
	public void dayCycle(){
		DayCycle.goingDark = true;
		DayCycle.shouldUpdate = true;
	}
	
	
	public void render(Screen screen){
		screen.renderUI(x,y-400,sprite);
	}
	
	public void drawMouseItem(Screen screen){
		
		if(input.k1) this.mouseTile = Tile.HQTile;
		if(input.k2) this.mouseTile = Tile.baseWithBubbleTile;
		if(input.k3) this.mouseTile = Tile.baseNoBubbleTile;
		if(input.k4) this.mouseTile = Tile.storageSiloTile;
		
		if(this.mouseTile != null){
			this.mouseTile.render(screen);
		}
		
	}
	
	//Setter methods
	public void setKeyBoard(Keyboard key){
		this.input = key;
	}
	
	public void setSprite(Sprite sprite){
		this.sprite = sprite;
	}
	
	//Method to add buildings to the buildZone
	public void addBuilding(Building building){
		((BuildLevel) buildZone).buildings.add(building);
	}
	
	//Methods that are run to add initial buildings, lights, and other objects.
	public void addStartingBuildings(){
		Building HQ = new HeadQuarters(32,32,"Mine",100,"5 Gold");
		Building Farm = new Farm(32,128,"Farm",100,"5 gold");
		Building Silo = new Silo(128,128,"Silo",100,"5 gold");
		((BuildLevel) buildZone).buildings.add(Silo);
		((BuildLevel) buildZone).buildings.add(HQ);
		((BuildLevel) buildZone).buildings.add(Farm);
	}
	
	public void addStartingLights(){
		
		((BuildLevel) buildZone).lights.add(new Point(0,0));
	}
}
