package com.engine.terraform.entity.light;

import com.engine.terraform.graphics.Screen;

public class GenericLight extends Light {
	
	public GenericLight(){
		lightDistance = 0;
		lightColor = 0;
		lightIntensity = 0.0f;
	}
	
	public GenericLight(int lightDistance, int lightColor, int lightIntensity){
		this.lightDistance = lightDistance;
		this.lightColor = lightColor;
		this.lightIntensity = lightIntensity;
	}
	
	public void render(int x, int y, Screen screen){
		screen.renderLight(x << 4, y << 4, this);
	}
	
}
