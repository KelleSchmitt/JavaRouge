package com.engine.terraform.entity.light;

import com.engine.terraform.graphics.Screen;

public class DayCycle extends Light {

	public static boolean shouldUpdate;
	public static boolean goingDark;
	
	public DayCycle(){
		
	}
	
	public void render(int x, int y, Screen screen){
		if(shouldUpdate){
			screen.renderDayCycle( x, y, this); 
		}
	}
}
