package com.engine.terraform.entity.light;

import com.engine.terraform.graphics.Screen;

public class Light {

	public int lightDistance;
	public int lightColor;
	public float lightIntensity;
	public int x;
	public int y;
	
	public static Light genericLight = new GenericLight(32,0,50);
	public static Light dayCycle = new DayCycle();
	
	protected Light(){
		
	}
	
	public void render(int x, int y, Screen screen){
		
	}
	
	
	
}
