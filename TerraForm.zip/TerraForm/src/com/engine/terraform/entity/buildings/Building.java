package com.engine.terraform.entity.buildings;

import java.io.Serializable;

import com.engine.terraform.graphics.Screen;
import com.engine.terraform.graphics.Sprite;
import com.engine.terraform.level.tile.Tile;

public class Building implements Serializable{
	private static final long serialVersionUID = 1L;
	public int x;
	public int y;
	public String name;
	public int health;
	public String cost;
	public int xTileCount = 2;
	public int yTileCount = 2;
	
	protected Building(){
		//Shouldn't used
	}
	
	protected Building(int x, int y, String name, int health, String cost){
		this.x = x;
		this.y = y;
		this.name = name;
		this.health = health;
		this.cost = cost;
	}

	public void renderBuilding(int x, int y, Screen screen) {
		// TODO Auto-generated method stub
		
	}

}
