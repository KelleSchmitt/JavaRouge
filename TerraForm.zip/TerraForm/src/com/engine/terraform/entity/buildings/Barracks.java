package com.engine.terraform.entity.buildings;

import com.engine.terraform.graphics.Screen;
import com.engine.terraform.level.tile.Tile;

public class Barracks extends Building {
	private static final long serialVersionUID = 1L;

	public Barracks(int x, int y, String name, int health, String cost){
		super(x,y,name,health,cost);
		yTileCount = 1;
	}
	
	
	public void renderBuilding(int x, int y, Screen screen){
		Tile.barracksLeftTile.renderBuilding(x,y,screen);
		Tile.barracksLeftTile.renderBuilding(x+32,y,screen);
	}
}
