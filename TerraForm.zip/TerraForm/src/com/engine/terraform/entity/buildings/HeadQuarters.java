package com.engine.terraform.entity.buildings;

import com.engine.terraform.graphics.Screen;
import com.engine.terraform.level.tile.Tile;

public class HeadQuarters extends Building {
	private static final long serialVersionUID = 1L;
	
	public HeadQuarters(int x, int y, String name, int health, String cost){
		super(x,y,name,health,cost);
	}
	
	public void renderBuilding(int x, int y, Screen screen){
		Tile.HQTile.renderBuilding(x, y, screen);
	}

}
