package com.engine.terraform.entity;

import java.util.Random;

import com.engine.terraform.graphics.Screen;
import com.engine.terraform.level.Level;

public abstract class Entity {

	public int x, y;
	private boolean removed = false;
	protected Level level;
	protected final Random random = new Random();
	
	public void update(){
		
	}
	
	public void render(Screen screen){
		
	}
	
	public void remove(){removed = true;} // Remove from Level
	
	public boolean isRemoved(){return removed;}
}
