package com.engine.terraform.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.engine.terraform.entity.mob.Player;

public class SaveHandler {
	
	public static Player loadPlayers(int id){
		
		Player player = null;
		String saveFile = "playerSave" + id + ".bin";
		String path = "playerSaves/";
		
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		
		try{
			fis = new FileInputStream(path + saveFile);
			ois = new ObjectInputStream(fis);
			
			player = (Player) ois.readObject();
			
			fis.close();
			ois.close();
		}catch(FileNotFoundException ex){
			
			SaveHandler.savePlayer(id, null);
			player = SaveHandler.loadPlayers(id);
			
		}catch(Exception ex){
			ex.printStackTrace();
			System.err.println("File could not load!");
		}
		
		return player;
	}
	
	public static void savePlayer(int id, Player player){
		
		String saveFile = "playerSave" + id + ".bin";
		String path = "playerSaves/";
		boolean success = (new File(path).mkdir());
		
		path += saveFile;
		
		File save = new File(path);
		
		//Start saving the player
		FileOutputStream fos;
		ObjectOutputStream oos;
		
		try{
			fos = new FileOutputStream(save);
			oos = new ObjectOutputStream(fos);
			
			oos.writeObject(player);
			oos.close();
		}catch(Exception ex){
			
			
		}
		
		
	}
	
	public static void deleteSave(int id){
		SaveHandler.savePlayer(id, null);
	}
}
