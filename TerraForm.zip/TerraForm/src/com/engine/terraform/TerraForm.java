package com.engine.terraform;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JFrame;

import com.engine.terraform.entity.mob.Player;
import com.engine.terraform.graphics.Screen;
import com.engine.terraform.input.Keyboard;
import com.engine.terraform.input.Mouse;
import com.engine.terraform.level.BuildLevel;
import com.engine.terraform.level.Level;
import com.engine.terraform.level.RandomLevel;

public class TerraForm extends Canvas implements Runnable {

	private static final long serialVersionUID = 1L;
	public static boolean mainWorld = false;
	public static boolean isBuilding = false;
	public static boolean inMenu = false;
	public static boolean isPaused = false;
	public static int width = 180;
	public static int height = 180;
	public static int scale = 3;
	private static String title = "Terraform v 0.1";
	
	private Thread gameThread;
	private JFrame frame;
	private Keyboard key;
	private Mouse mouse;
	private Level level;
	private Level buildZone;
	private Player player;
	private boolean isRunning = false;
	private boolean inGame = false;
	
	private Screen screen;
	
	private BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
	private int[] pixels = ((DataBufferInt)image.getRaster().getDataBuffer()).getData();
	
	public TerraForm(){
		Dimension size = new Dimension(width*scale,height*scale);
		setPreferredSize(size);
		setMinimumSize(size);
		setMaximumSize(size);
		
		screen = new Screen(width, height);
		frame = new JFrame();
		key = new Keyboard();
		mouse = new Mouse();
		level = new RandomLevel(64,64);
		buildZone = new BuildLevel(10,10, screen);
		player = new Player(96,96,key, mouse, buildZone);
		
		addKeyListener(key);
		addMouseListener(mouse);
		addMouseMotionListener(mouse);
		
		inGame = true;
		mainWorld = true;
		//How to handle saves
		/*******
		
		//Saving the player
		SaveHandler.savePlayer(1, player);
		
		//Loading the player
		player = SaveHandler.loadPlayers(1);
		player.setKeyBoard(key);
		player.setSprite(Sprite.UI);
		
		********/	
		
	}
	
	public synchronized void start(){
		isRunning = true;
		gameThread = new Thread(this,"Display");
		gameThread.start();
	}
	
	public synchronized void stop(){
		isRunning = false;
		try{
			gameThread.join();
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		
	}
	
	public void run(){
		long lastTime = System.nanoTime();
		long timer = System.currentTimeMillis();
		final double ns = 1000000000.0 / 60.0;
		double delta = 0;
		int frames = 0;
		int updates = 0;
		requestFocus();
		
		while(isRunning){
			long now = System.nanoTime();
			delta += (now-lastTime) /ns;
			lastTime = now;
			
			//Lock the framerate at a max fps
			while(delta >= 1){
				update();
				updates++;
				delta--;
			}
			render();
			frames++;
			
			if(System.currentTimeMillis() - timer > 1000){
				timer += 1000;
				frame.setTitle(title + " | " + updates + " ups, " + frames + ", fps");
				updates = 0;
				frames = 0;
			}
		}
		stop();
	}
	
	public void update(){
		
		if(true){
			key.update();
			player.update();
			mouse.update();
		}else{
			
		}
	}
	
	public void render(){
		BufferStrategy bs = getBufferStrategy();
		if(bs == null){
			createBufferStrategy(3);
			return;
		}
		
		if(inGame){
			screen.clear();
			int xScroll = player.x-screen.width/2;
			int yScroll = player.y-screen.height/2;
			
			if(mainWorld){
				level.render(xScroll, yScroll, screen);
				player.render(screen);
			}else if(isBuilding){
				buildZone.render(xScroll, yScroll, screen);
				((BuildLevel) buildZone).renderBuildings();
				((BuildLevel) buildZone).renderLights();
				player.drawMouseItem(screen);
				
			}else if(inMenu){
				
			}else if(isPaused){
				
			}
			
			for(int i = 0; i < pixels.length; i++){
				pixels[i] = screen.pixels[i];
			}
		}else{
			this.stop();
		}
		
		
		Graphics g = bs.getDrawGraphics();
		g.drawImage(image,0,0,getWidth(),getHeight(),null);
		draw(g);
		g.dispose();
		bs.show();
	}
	
	public void draw(Graphics g){
		//All non sprite drawing will go here :)
		g.setColor(Color.WHITE);
		g.setFont(new Font("Tahoma", 0, 20));
		g.drawString(player.name, 10, 10);
		g.drawString(player.rank, 10, 30);
		g.drawString("Gold: " + player.gold, 10, 50);
		g.drawString("Coal: " + player.coal, 10, 70);
		
	}

	public static void main(String[] args) {
		TerraForm game = new TerraForm();
		game.frame.setResizable(false);
		game.frame.setTitle(title);
		game.frame.add(game);
		game.frame.pack();
		game.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		game.frame.setLocationRelativeTo(null);
		game.frame.setVisible(true);
		
		game.start();

	}

}
