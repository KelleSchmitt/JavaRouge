package com.engine.terraform.input;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class Keyboard implements KeyListener {

	private boolean[] keysPressed = new boolean[63354];
	private boolean[] keysReleased = new boolean[63354];
	public boolean up;
	public boolean down;
	public boolean left;
	public boolean right;
	public boolean space;
	public boolean esc;
	public boolean pause;
	public boolean enter;
	public boolean k1;
	public boolean k2;
	public boolean k3;
	public boolean k4;
	public boolean k5;
	public boolean k6;
	public boolean tab;
	public boolean i;
	public boolean j;
	public boolean k;
	public boolean l;
	
	public void update(){
		up = keysPressed[KeyEvent.VK_UP]|| keysPressed[KeyEvent.VK_W];
		down = keysPressed[KeyEvent.VK_DOWN]|| keysPressed[KeyEvent.VK_S];
		left = keysPressed[KeyEvent.VK_LEFT]|| keysPressed[KeyEvent.VK_A];
		right = keysPressed[KeyEvent.VK_RIGHT]|| keysPressed[KeyEvent.VK_D];
		space = keysReleased[KeyEvent.VK_SPACE]; 
		esc = keysReleased[KeyEvent.VK_ESCAPE];
		pause = keysReleased[KeyEvent.VK_P];
		enter = keysReleased[KeyEvent.VK_ENTER];
		k1 = keysPressed[KeyEvent.VK_1];
		k2 = keysPressed[KeyEvent.VK_2];
		k3 = keysPressed[KeyEvent.VK_3];
		k4 = keysPressed[KeyEvent.VK_4];
		k5 = keysPressed[KeyEvent.VK_5];
		k6 = keysPressed[KeyEvent.VK_6];
		tab = keysReleased[KeyEvent.VK_TAB];
		i = keysPressed[KeyEvent.VK_I];
		j = keysPressed[KeyEvent.VK_J];
		k = keysPressed[KeyEvent.VK_K];
		l = keysPressed[KeyEvent.VK_L];
		
	}
	
	
	
	@Override
	public void keyPressed(KeyEvent e) {
		keysPressed[e.getKeyCode()] = true;
		keysReleased[e.getKeyCode()] = false;
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		keysPressed[e.getKeyCode()] = false;
		keysReleased[e.getKeyCode()] = true;
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
	}
	
	public void keyReleasedSetter(int e, boolean bool){
		keysReleased[e] = bool;
	}

}
