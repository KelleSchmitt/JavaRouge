package com.engine.terraform.input;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import com.engine.terraform.level.tile.Tile;

public class Mouse implements MouseListener, MouseMotionListener {

	public static int mouseX;
	public static int mouseY;
	
	public boolean isClicked;
	public boolean isDragged;
	
	public void update(){
		
		if(isDragged){
			//System.out.println("DRAGGING");
		}
		if(isClicked){
			//System.out.println("CLICK");
			isClicked = false;
		}
		
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		Mouse.mouseX = e.getX();
		Mouse.mouseY = e.getY();
		isDragged = true;
		isClicked = false;
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		Mouse.mouseX = e.getX();
		Mouse.mouseY = e.getY();
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Mouse.mouseX = e.getX();
		Mouse.mouseY = e.getY();
		isClicked = true;
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		isDragged = false;
		
	}

}
