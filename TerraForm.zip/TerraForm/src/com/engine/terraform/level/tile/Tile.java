package com.engine.terraform.level.tile;

import com.engine.terraform.graphics.Sprite;
import com.engine.terraform.graphics.Screen;
import com.engine.terraform.graphics.SpriteSheet;

public class Tile {

	public int x, y;
	public Sprite sprite;
	
	//Tiles go here
	public static Tile voidTile = new VoidTile(Sprite.voidSprite);
	public static Tile sandTileSolid = new SandTile(Sprite.sandSpriteSolid);
	
	
	//Dirt Tiles
	public static Tile dirtTileSolid = new DirtTile(Sprite.dirtSpriteSolid);
	public static Tile dirtTileLeftMid = new DirtTile(Sprite.dirtSpriteLeftMid);
	public static Tile dirtTileTopLeft = new DirtTile(Sprite.dirtSpriteTopLeft);
	public static Tile dirtTileTopMid = new DirtTile(Sprite.dirtSpriteTopMid);
	public static Tile dirtTileTopRight = new DirtTile(Sprite.dirtSpriteTopRight);
	public static Tile dirtTileRightMid = new DirtTile(Sprite.dirtSpriteRightMid);
	public static Tile dirtTileBottomRight = new DirtTile(Sprite.dirtSpriteBottomRight);
	public static Tile dirtTileBottomMid = new DirtTile(Sprite.dirtSpriteBottomMid);
	public static Tile dirtTileBottomLeft = new DirtTile(Sprite.dirtSpriteBottomLeft);
	public static Tile dirtTileMid = new DirtTile(Sprite.dirtSpriteMid);
	public static Tile dirtTileNoLeftRight = new DirtTile(Sprite.dirtSpriteNoLeftRight);
	public static Tile dirtTileNoLeftBottom = new DirtTile(Sprite.dirtSpriteNoLeftBottom);
	public static Tile dirtTileOnlyBottom = new DirtTile(Sprite.dirtSpriteOnlyBottom);
	public static Tile dirtTileOnlyRight = new DirtTile(Sprite.dirtSpriteOnlyRight);
	public static Tile dirtTileOnlyTop = new DirtTile(Sprite.dirtSpriteOnlyTop);
	public static Tile dirtTileOnlyLeft = new DirtTile(Sprite.dirtSpriteOnlyLeft);
	public static Tile dirtTileNoRightBottom = new DirtTile(Sprite.dirtSpriteNoRightBottom);
	public static Tile dirtTileNoLeftTop = new DirtTile(Sprite.dirtSpriteNoLeftTop);
	public static Tile dirtTileNoTopBottom = new DirtTile(Sprite.dirtSpriteNoTopBottom);
	public static Tile dirtTileNoRightTop = new DirtTile(Sprite.dirtSpriteNoRightTop);
	
	//Water Tiles
	public static Tile waterTileSolid = new WaterTile(Sprite.waterSpriteSolid);
	
	//Water+Sand
	public static Tile waterTileSandLeft = new WaterTile(Sprite.waterSpriteSandLeft);
	public static Tile waterTileSandTop = new WaterTile(Sprite.waterSpriteSandTop);
	public static Tile waterTileSandRight = new WaterTile(Sprite.waterSpriteSandRight);
	public static Tile waterTileSandBottom = new WaterTile(Sprite.waterSpriteSandBottom);
	public static Tile waterTileSandRightTop = new WaterTile(Sprite.waterSpriteSandRightTop);
	public static Tile waterTileSandLeftTop = new WaterTile(Sprite.waterSpriteSandLeftTop);
	public static Tile waterTileSandLeftBottom = new WaterTile(Sprite.waterSpriteSandLeftBottom);
	public static Tile waterTileSandRightBottom = new WaterTile(Sprite.waterSpriteSandRightBottom);
	public static Tile waterTileSandLeftRight = new WaterTile(Sprite.waterSpriteSandLeftRight);
	public static Tile waterTileSandTopBottom = new WaterTile(Sprite.waterSpriteSandTopBottom);
	
	//Water+Dirt
	public static Tile waterTileDirtTop = new WaterTile(Sprite.waterSpriteDirtTop);
	public static Tile waterTileDirtBottom = new WaterTile(Sprite.waterSpriteDirtBottom);
	public static Tile waterTileDirtLeft = new WaterTile(Sprite.waterSpriteDirtLeft);
	public static Tile waterTileDirtRight = new WaterTile(Sprite.waterSpriteDirtRight);
	public static Tile waterTileDirtRightTop = new WaterTile(Sprite.waterSpriteDirtRightTop);
	public static Tile waterTileDirtLeftTop = new WaterTile(Sprite.waterSpriteDirtLeftTop);
	public static Tile waterTileDirtRightBottom = new WaterTile(Sprite.waterSpriteDirtRightBottom);
	public static Tile waterTileDirtLeftBottom = new WaterTile(Sprite.waterSpriteDirtLeftBottom);
	public static Tile waterTileDirtLeftRight = new WaterTile(Sprite.waterSpriteDirtLeftRight);
	public static Tile waterTileDirtTopBottom = new WaterTile(Sprite.waterSpriteDirtTopBottom);
	
	//Buildings go Below!
	//HQ
	public static Tile HQTile = new BuildingTile(Sprite.HQSprite);
	
	//Barracks
	public static Tile barracksLeftTile = new BuildingTile(Sprite.BarracksLeft);
	public static Tile barracksRightTile = new BuildingTile(Sprite.BarracksRight);
	
	//Farm
	public static Tile farmLeftTile = new BuildingTile(Sprite.FarmLeft);
	public static Tile farmRightTile = new BuildingTile(Sprite.FarmRight);
	
	//Storage Silo
	public static Tile storageSiloTile = new BuildingTile(Sprite.storageSilo);
	
	//BASES
	public static Tile baseNoBubbleTile = new BuildingTile(Sprite.baseNoBubble);
	public static Tile baseWithBubbleTile = new BuildingTile(Sprite.baseWithBubble);
	
	//Player UI
	public static Tile UI = new PlayerTile(Sprite.UI);
	
	public Tile(Sprite sprite){
		this.sprite = sprite;
	}
	
	public void render(int x, int y, Screen screen){
		
	}
	
	public void renderBuilding(int x, int y, Screen screen){
		screen.renderBuilding(x, y, this);
	}
	
	public void render(Screen screen){
		screen.renderTile(this);
	}
	
	public boolean solid(){
		return false;
	}
}
