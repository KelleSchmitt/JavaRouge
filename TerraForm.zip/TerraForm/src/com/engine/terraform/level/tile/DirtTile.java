package com.engine.terraform.level.tile;

import com.engine.terraform.graphics.Screen;
import com.engine.terraform.graphics.Sprite;

public class DirtTile extends Tile {

	public DirtTile(Sprite sprite){
		super(sprite);
	}
	
	public void render(int x, int y, Screen screen){
		screen.renderTile(x << 4, y << 4, this);
	}
}
