package com.engine.terraform.level.tile;

import com.engine.terraform.graphics.Screen;
import com.engine.terraform.graphics.Sprite;

public class VoidTile extends Tile {

	public VoidTile(Sprite sprite){
		super(sprite);
	}
	
	public void render(int x, int y, Screen screen){
		//render here
		screen.renderTile(x << 4, y << 4, this);
	}
}
