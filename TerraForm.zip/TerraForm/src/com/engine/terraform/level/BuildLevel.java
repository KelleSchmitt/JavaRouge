package com.engine.terraform.level;

import java.awt.Rectangle;
import java.util.ArrayList;

import com.engine.terraform.Utilities.Point;
import com.engine.terraform.entity.buildings.Building;
import com.engine.terraform.entity.light.Light;
import com.engine.terraform.graphics.Screen;

public class BuildLevel extends Level {
	private static final long serialVersionUID = 1L;
	public ArrayList<Building> buildings;
	public ArrayList<Point> lights;
	public Screen screen;
	
	
	public BuildLevel(int width, int height, Screen screen) {
		super(width, height);
		this.screen = screen;
		buildings = new ArrayList<Building>();
		lights = new ArrayList<Point>();
	}

	
	protected void generateLevel(){
		
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				tiles[x+y*width]  = 0; //Sand
			}
		}
		
	}
	
	public boolean checkCollisions(int xa, int ya, int width, int height){
		Rectangle param = new Rectangle(xa, ya, width, height);
		Rectangle tmp = null;
		for(Building a: buildings){
			tmp = new Rectangle(a.x,a.y,a.xTileCount*64,a.yTileCount*64);
			if(tmp.contains(param)){
				return true;
			}
		}
		
		
		return false;
	}
	
	public void renderBuildings(){
		for(Building a: buildings){
			a.renderBuilding(a.x, a.y, screen);
		}
	}
	
	public void renderLights(){
		for(Point a: lights){
			Light.genericLight.render(a.x, a.y, screen);
		}
	}
}
