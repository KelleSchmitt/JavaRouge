package com.engine.terraform.level;

import java.io.Serializable;

import com.engine.terraform.entity.light.GenericLight;
import com.engine.terraform.entity.light.Light;
import com.engine.terraform.graphics.Screen;
import com.engine.terraform.level.tile.Tile;

public class Level implements Serializable {

	private static final long serialVersionUID = 1L;
	protected int width, height;
	protected int[] tiles;
	
	public Level(int width, int height){
		this.width = width;
		this.height = height;
		tiles = new int[width*height];
		generateLevel();
	}
	
	public Level(String path){
		loadLevel(path);
	}
	
	protected void generateLevel(){
		
	}
	
	protected void loadLevel(String path){
		
	}
	
	public void update(){
		
	}
	
	private void time(){
		
	}
	
	public void render(int xScroll, int yScroll, Screen screen){
		screen.setOffset(xScroll, yScroll);
		int x0 = xScroll >> 4;
		int x1 = (xScroll + screen.width + 16) >> 4;
		int y0 = yScroll >> 4;
		int y1 = (yScroll + screen.height + 16) >> 4;
		
		for(int y = y0; y < y1; y++){
			for(int x = x0; x < x1; x++){
				getTile(x,y).render(x,y,screen);
			}
		}
		
		/**Tiles
		Tile.storageSiloTile.render(3, 3, screen);
		Tile.barracksLeftTile.render(1, 1, screen);
		Tile.barracksRightTile.render(2, 1, screen);
		Tile.HQTile.render(4, 4, screen);
		Tile.baseWithBubbleTile.render(6, 6, screen);
		Tile.baseNoBubbleTile.render(8,8,screen);
		Tile.voidTile.render(3, 2, screen);
		Tile.voidTile.render(3, 3, screen);
		Tile.voidTile.render(4, 2, screen);
		Tile.voidTile.render(4,3,screen);
		
		//Lights
		Light.genericLight.render(3, 2, screen);
		**/
		
		
		
		
		//Skip Day/Night Cycle for now, I'm having problems!
		//Light.dayCycle.render(0,0,screen);
	}
		
	public Tile getTile(int x, int y){
		
		if(x < 0 || y < 0 || x >= width || y >= height) return Tile.voidTile;
		int id = tiles[x+y*width];
		if(id == 0) return Tile.sandTileSolid;
		if(id == 15) return Tile.dirtTileSolid;
		if(id == 16) return Tile.dirtTileMid;
		//if(id == 1 || id == 2 || id == 4 || id == 7 || id == 8 || id == 11 || id == 13 || id == 14) return Tile.dirtTileSolid;
		if(id == 1) return Tile.dirtTileOnlyTop;
		if(id == 2) return Tile.dirtTileOnlyRight;
		if(id == 3) return Tile.dirtTileNoRightTop;
		if(id == 4) return Tile.dirtTileOnlyBottom;
		if(id == 5) return Tile.dirtTileNoLeftRight;
		if(id == 6) return Tile.dirtTileNoRightBottom;
		if(id == 7) return Tile.dirtTileRightMid;
		if(id == 8) return Tile.dirtTileOnlyLeft;
		if(id == 10) return Tile.dirtTileNoTopBottom;
		if(id == 9) return Tile.dirtTileNoLeftTop;
		if(id == 11) return Tile.dirtTileBottomMid;
		if(id == 12) return Tile.dirtTileNoLeftBottom;
		if(id == 13) return Tile.dirtTileLeftMid;
		if(id == 14) return Tile.dirtTileTopMid;
		//if(tiles[x+y*width] == 0) return Tile.grass;
		return Tile.voidTile;
	}
}
