package com.engine.terraform.level;

import java.util.Random;

public class RandomLevel extends Level {
	
	private final int EAST = 2;
	private final int SOUTH = 4;
	private final int WEST = 8;
	private final int NORTH = 1;
	
	/*********1**********
	 * ******   *********
	 * ****8  x  2*******
	 * ******   *********
	 * *******4**********/
	
	
	
	private static final Random random = new Random();
	
	public RandomLevel(int width, int height){
		super(width, height);
	}
	
	protected void generateLevel(){
		
		//0 == sand
		//1 == dirt
		//2 == water
		//3 == snow
		
		int[] tmpTiles = new int[width*height];
		
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				int rand = random.nextInt(100);
				double chance = 5;
				
				if(x > 0 ){
					if(tmpTiles[(x-1)+y*width] == 1) chance += 65;
				}
				
				if(y > 0){
					if(tmpTiles[x+(y-1)*width] == 1) chance += 65;
				}

				if(chance > 70) chance = 80;
				if(rand < chance){
					tmpTiles[x+y*width] = 1;
					
				}else
					tmpTiles[x+y*width] = 0;
			}
		}
		
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				
				if( x-1 >= 0 && x+1 < width && tmpTiles[(x+1)+y*width] == 1 && y-1 >= 0 && y+1 < height){
					if(tmpTiles[(x+1)+y*width] == 1 && tmpTiles[(x-1)+y*width] == 1 && tmpTiles[x+(y+1)*width] == 1 && tmpTiles[x+(y-1)*width] == 1){
						tmpTiles[x+y*width] = 1;
					}
				}
				
			}
		}
		
		
		
		//Experimental dirt placement, using dirt locations.
		//Works Fairly nice.
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				int id = 0;
				if(tmpTiles[x+y*width] != 0){
					if( x >= 0 && x+1 < width && tmpTiles[(x+1)+y*width] == 1){
						id += EAST;
					}
					if( y >= 0 && y+1 < height && tmpTiles[x+(y+1)*width] == 1){
						id += SOUTH;
					}
					if( x-1 >= 0 && x < width && tmpTiles[(x-1)+y*width] == 1){
						id += WEST;
					}
					if(y-1 >= 0 && y < height && tmpTiles[x+(y-1)*width] == 1){
						id += NORTH;
					}
					if(id == 0){
						id = 16;
					}
				}
				tiles[x+y*width] = id;
				
			}
		}
		
	}

}
